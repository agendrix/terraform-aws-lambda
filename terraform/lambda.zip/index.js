"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.__test__ = void 0;
const aws_sdk_1 = __importDefault(require("aws-sdk"));
const handler = async (event, context) => {
    const s3 = new aws_sdk_1.default.S3();
    const data = {
        text: "Hello World",
        event,
        context,
        listBuckets: await s3.listBuckets().promise(),
    };
    return {
        statusCode: 200,
        body: JSON.stringify(data),
        headers: { "Content-Type": "text/html; charset=utf-8" },
        isBase64Encoded: false,
    };
};
exports.handler = handler;
exports.__test__ = {
    handler,
};
